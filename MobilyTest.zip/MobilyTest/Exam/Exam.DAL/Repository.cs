﻿using System.Collections.Concurrent;
using System.Runtime.Caching;
using System.Text;
using System.Threading.Tasks;

namespace Exam.DAL
{
    public class Repository : IRepository
    {
        ObjectCache cache = MemoryCache.Default;
        private static readonly object _cacheLock = new object();
        private static readonly object _constructorLock = new object();

        static readonly string _cacheName = "words";

        ConcurrentDictionary<string, int> _Data
        {
            get
            {
                ConcurrentDictionary<string, int> result = cache[_cacheName] as ConcurrentDictionary<string, int>;

                return result;
            }
            set
            {
                CacheItemPolicy policy = new CacheItemPolicy();
                lock (_cacheLock)
                {
                    cache.Set(_cacheName, value, policy);
                }
            }
        }

        public Repository()
        {
            lock (_constructorLock)
            {
                if (this._Data == null)
                    this._Data = new ConcurrentDictionary<string, int>();
            }
        }        

        public async Task<ConcurrentDictionary<string, int>> GetData()
        {
            return await Task.Run(() => { return this._Data; });
        }

        public async Task<bool> SetData(StringBuilder sb)
        {
            bool result = await Task.Run(() =>
            {
                bool taskResult = true;
                try
                {                    
                    lock (_cacheLock)
                    {
                        string key = sb.ToString();
                        if (this._Data.ContainsKey(key))
                            this._Data[key]++;
                        else this._Data[key] = 1;
                    }
                }
                catch
                {
                    taskResult = false;
                }

                return taskResult;
            });

            return result;
        }
    }
}

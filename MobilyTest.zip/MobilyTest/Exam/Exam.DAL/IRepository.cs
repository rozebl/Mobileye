﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace Exam.DAL
{
    public interface IRepository
    {
        Task<ConcurrentDictionary<string, int>> GetData();
        Task<bool> SetData(StringBuilder sb);
    }
}

﻿using Exam.BL.Interfaces;
using Exam.DAL;
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Exam.BL
{
    public class BusinessLogic : IBusinessLogic
    {
        private readonly IRepository _repository;


        public BusinessLogic(IRepository repository)
        {
            this._repository = repository;
        }

        public string CheckHealth()
        {
            string result = "I am running";

            return result;
        }

        public async Task<int> GetWordCounter(string word)
        {
            int result = 0;

            ConcurrentDictionary<string, int> dic = await this._repository.GetData();
            if(dic.ContainsKey(word))
                result = dic[word]; 

            return result;
        }

        public async Task<bool> InputText(string source)
        {
            bool result = true;
            try
            {
                if (File.Exists(source))
                {
                    result = await InputFromFile(source);
                }
                else if (Uri.IsWellFormedUriString(source, UriKind.Absolute))
                {
                    result = await InputFromUrl(source);
                }
                else result = await InputFromString(source);
            }
            catch
            {
                result = false;
            }

            return result;
        }

        public async Task<bool> InputFromUrl(string url)
        {
            bool result = true;

            using (WebClient client = new WebClient())
            {
                using (Stream stream = client.OpenRead(url))
                {
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        result = await ProcessFromStreamReader(reader);
                    }
                }
            }

            return result;
        }

        public async Task<bool> InputFromString(string data)
        {
            bool result = true;

            using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(data)))
            {
                using (StreamReader reader = new StreamReader(stream))
                {
                    result = await ProcessFromStreamReader(reader);
                }
            }

            return result;
        }

        public async Task<bool> InputFromFile(string fileName)
        {
            bool result = false;

            using (var reader = new StreamReader(fileName))
            {
                result = await ProcessFromStreamReader(reader);
            }

            return result;
        }

        private async Task<bool> ProcessFromStreamReader(StreamReader sr)
        {
            bool result = true;
            try
            {
                var sb = new StringBuilder();
                char[] charBuffer = new char[1];

                for (int i = 0; !sr.EndOfStream && result; i++)
                {
                    await sr.ReadAsync(charBuffer, 0, 1);
                    if ((charBuffer[0] >= 'A' && charBuffer[0] <= 'Z') || (charBuffer[0] >= 'a' && charBuffer[0] <= 'z'))
                    {
                        sb.Append(charBuffer[0]);
                    }
                    else
                    {
                        if (sb.Length == 0)
                            continue;
                        else
                            result = await SetData(sb);
                    }
                }

                if (sb.Length > 0)
                    result = await SetData(sb);
            }
            catch
            {
                result = false;
            }

            return result;
        }

        private async Task<bool> SetData(StringBuilder sb)
        {
            bool result = await this._repository.SetData(sb);

            sb.Clear();

            return result;
        }
    }
}

﻿using System.Threading.Tasks;

namespace Exam.BL.Interfaces
{
    public interface IBusinessLogic
    {
        string CheckHealth();
        Task<bool> InputText(string source);
        Task<int> GetWordCounter(string word);
    }
}

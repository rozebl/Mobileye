﻿using Exam.BL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Exam.Controllers
{
    public class MainController : ControllerBase
    {
        private readonly IBusinessLogic businessLogic;

        public MainController(IBusinessLogic _businessLogic)
        {
            this.businessLogic = _businessLogic;
        }

        [HttpGet]
        public IActionResult CheckHealth()
        {
            string result = this.businessLogic.CheckHealth();

            return Ok(result);
        }

        [HttpGet]
        public async Task<IActionResult> GetWordCounter(string word)
        {
            var result = await this.businessLogic.GetWordCounter(word);

            return Ok(result);
        }

        [HttpPost]
        public async Task<IActionResult> InputText([FromBody]string source)
        {
            var result = await this.businessLogic.InputText(source);

            return Ok(result);
        }
    }
}
